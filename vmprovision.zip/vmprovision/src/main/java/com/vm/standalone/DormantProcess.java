package com.vm.standalone;

public class DormantProcess {

}
