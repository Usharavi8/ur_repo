package com.vm.dao;

import java.util.Random;

public class readmail {
 public static void main(String[] args) throws Exception {
 /* ExchangeService service = new ExchangeService();
  // Provide Crendentials
  ExchangeCredentials credentials = new WebCredentials("vmuser1@mfdmlab.com", "India@2020");
  service.setCredentials(credentials);

  // Set Exchange WebSevice URL
  service.setUrl(new URI("https://exch2013.mfdmlab.com/EWS/Exchange.asmx"));

  // Get five items from mail box
  ItemView view = new ItemView(1);

  // Search Inbox
  FindItemsResults<Item> findResults = service.findItems(WellKnownFolderName.Inbox, view);
 
  
  // iterate thru items
  for (Item item : findResults.getItems()) {
	 item.load();
	 System.out.println(item.getSubject());
	 System.out.println(item.getBody());
	 System.out.println(item.getId());
	// System.out.println(item.get));
*/  
	 
	 
	 Random rand = new Random(); 
	  
     // Generate random integers in range 0 to 999 
     int rand_int1 = rand.nextInt(10000); 
     int rand_int2 = rand.nextInt(10000); 

     // Print random integers 
     System.out.println("Random Integers: "+rand_int1); 
     System.out.println("Random Integers: "+rand_int2); 

     // Generate Random doubles 
     double rand_dub1 = rand.nextDouble(); 
     double rand_dub2 = rand.nextDouble(); 

     // Print random doubles 
     System.out.println("Random Doubles: "+rand_dub1); 
     System.out.println("Random Doubles: "+rand_dub2); 
     
	 Random random = new Random(); 

     String id = String.format("%04d", random.nextInt(10000));
     
     System.out.println(id);

 }
} 