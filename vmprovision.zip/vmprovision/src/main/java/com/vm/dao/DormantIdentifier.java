package com.vm.dao;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;

import com.vm.db.util.HibernateUtils;

public class DormantIdentifier {
	static Logger log = Logger.getLogger(DormantIdentifier.class);
	
	public static String dormantDetails(String memory,String cpu,String diskSpace,String name,String cateogory,String converId,String tcktId,String channel,String empName,String empMail,String desc,String date,String gl_id,String gl_mail,String req_for,String days) {
		org.hibernate.Query query = null;
		org.hibernate.Session session = null;
		org.hibernate.Transaction tx = null;
		String availStatus="";
		String dormantAvail="select * from vm_details where idle_state=1";
		String getMemory="select * from vm_details where idle_state=1 and storage_memory=:memory and cpu=:cpu and disk_space=:disk";
		
		try {
			
			session=new HibernateUtils().getSession();//factory.openSession();
			try {
			tx = session.beginTransaction();
	        query = session.createSQLQuery("insert into vm_requestor (user_name, type , ram, cpu, hdd , created_on, ticket_id, conversation_id, channel,emp_name,emp_mail,descr,gl_id,gl_mail,required_for,days)"
	        		+ " VALUES(:user_name,:type,:ram,:cpu,:hdd,:date,:ticket,:conversationId,:channel,:empName,:empMail,:desc,:gl_id,:gl_mail,:req_for,:days)");
			query.setParameter("user_name", name);
			query.setParameter("type", cateogory);
			query.setParameter("ram", memory);
			query.setParameter("cpu", Integer.parseInt(cpu));
			query.setParameter("hdd", diskSpace);
			query.setParameter("ticket", tcktId);
			Date dt=new Date();
			SimpleDateFormat displayFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			if(!date.equals("") && date!=null){
				/*DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			    System.out.println(sdf.format(date));
				query.setParameter("date", Timestamp.valueOf(sdf.format(date)));*/
				DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			    Date date1 = new Date();
			    System.out.println(sdf.format(date1));
				query.setParameter("date", Timestamp.valueOf(sdf.format(date1)));
			}else{
				DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			    Date date1 = new Date();
			    System.out.println(sdf.format(date1));
				query.setParameter("date", Timestamp.valueOf(sdf.format(date1)));
			}
			query.setParameter("conversationId", converId);
			query.setParameter("channel", channel);
			query.setParameter("empName", empName);
			query.setParameter("empMail", empMail);
			query.setParameter("desc", desc);
			query.setParameter("gl_id", gl_id);
			query.setParameter("gl_mail", gl_mail);
			query.setParameter("req_for", req_for);
			query.setParameter("days", days);
	        query.executeUpdate();
			tx.commit();
			}catch(Exception e) {
				e.printStackTrace();
			}
	        query = session.createSQLQuery(dormantAvail);
	        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
	        List data = query.list();
	        for(Object object : data)
		       {
	        	availStatus="Available";
				}
	        if(availStatus.equalsIgnoreCase("Available")) {
	        query = session.createSQLQuery(getMemory);
	        query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
	        query.setParameter("memory", memory);
	        query.setParameter("cpu", cpu);
	        query.setParameter("disk", diskSpace);
	        List data1 = query.list();
	        for(Object object : data1)
		       {
	        	Map row = (Map) object;
	        	String mem=(String)row.get("storage_memory");
	        	String cpus=(String)row.get("cpu");
	        	String disk=(String)row.get("disk_space");

	        	if(mem.equals(memory) && cpus.equals(cpu) && disk.equals(diskSpace)) {
	        		availStatus="Available";
	        	}else {
	        		availStatus="Not Available";
	        	}
		        }
	    	  }
	   	    } catch (Exception e) {
			log.error("error Occurs in dormantDetails : "+e.getMessage());
		} finally {
			if (session != null ) {
				HibernateUtils.closeSession(session);
			}
		}
		return availStatus;
	}
}