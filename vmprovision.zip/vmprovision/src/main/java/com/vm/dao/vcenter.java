package com.vm.dao;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.vdurmont.emoji.EmojiParser;

public class vcenter
{
    private static SSLSocketFactory sslSocketFactory = null;

    /**
     * Use the VM argument <code>-Djavax.net.debug=ssl</code> for SSL specific debugging;
     * the SSL handshake will appear a single time when connections are re-used, and multiple
     * times when they are not.
     * 
     * Use the VM <code>-Djavax.net.debug=all</code> for all network related debugging, but 
     * note that it is verbose.
     * 
     * @throws Exception
     */
    public static void main(String[] args) throws Exception
    {
    	
    	
           /* URL url = null;
            HttpURLConnection httpUrlCon = null;
    		String respStr = null;
            try {
            	String postData="{\"channel\": \"vmprovisioning\", \"text\": \"Welcome Agilent Usha\"}";
            	long t = System.currentTimeMillis();
            	url = new URL("https://slack.com/api/chat.postMessage");
            	httpUrlCon = (HttpURLConnection) url.openConnection();
            	httpUrlCon.setRequestProperty("Content-Type", "application/json");
            	httpUrlCon.setRequestProperty("Authorization", "Bearer xoxb-579428186150-629275123446-KittuPVN8tnszEfM4ZvHHXdV");
            	httpUrlCon.setDoInput(true);
            	httpUrlCon.setDoOutput(true);
            	httpUrlCon.setConnectTimeout(75000);
            	httpUrlCon.setReadTimeout(75000);
            	  httpUrlCon.setRequestMethod("POST");
            	  IOUtils.write(postData, httpUrlCon.getOutputStream());
    	        respStr = IOUtils.toString(httpUrlCon.getInputStream());
    	        //logger.info("URL "+targetUrl+" REQUESRT XML "+postData); 
    	        //logger.info("Response time :: "+(System.currentTimeMillis()-t)+" ms");
    	        System.out.println("URL \n REQUESRT XML "+postData+"\nRESPONSE XML"+respStr); 
    	    } catch (Exception e) {
    	    	//logger.error("Exception caught::: "+targetUrl+" REQUESRT XML "+postData+" Reason "+e.getMessage(),e); 
    	    	//logger.error(" Exception caught::: url "+targetUrl+" Reason "+e.getMessage(),e);
    	        throw e;
            } finally {
    	       
            }*/
    	
    	
    	
    	
String result="";
        //URL url = new URL("https://google.com/");
        URL url = new URL("https://10.134.95.11/rest/com/vmware/cis/session");
        URL url1 = new URL("https://10.134.95.11/rest/vcenter/vm/vm-1200");
       // URL url2=new URL("https://mfdm.tcseia.com:8443/aglBotService");
        // Disable first  https://vcloud.example.com/api/admin/extension/vimServer/9/vmsList
        result= request(url, false);
        result=result.substring(10, result.length()-2);
        System.out.println("Resultant Token:"+result);
        result=postRequest(url1, false,result);
       
        // Enable; verifies our previous disable isn't still in effect.
       // request(url, true);
    }

    public static String request(URL url, boolean enableCertCheck) throws Exception {
        BufferedReader reader = null;
        // Repeat several times to check persistence.
        System.out.println("Cert checking=["+(enableCertCheck?"enabled":"disabled")+"]");
       // for (int i = 0; i < 5; ++i) {
        StringBuilder sb = new StringBuilder();
            try {
            	String loginPassword = "vcuser@eiamfdm.com"+ ":" + "Tcs@1234";
            	String encoded = new sun.misc.BASE64Encoder().encode (loginPassword.getBytes());
            	String ballEmoji = "\u26BD";
            	String bananaEmoji = "\uD83C\uDF4C";
            	String koreanFlagEmoji = "\uD83C\uDDF0\uD83C\uDDF7";
            	System.out.println(ballEmoji);
                 String smile_emoji = EmojiParser.parseToUnicode(":smiley: some text");
                 System.out.println(smile_emoji);
                HttpURLConnection httpConnection = (HttpsURLConnection) url.openConnection();
                httpConnection.setRequestMethod("POST"); // PUT is another valid option
                httpConnection.setRequestProperty("Content-Type", "application/json");
        	 	httpConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
        	 	httpConnection.setDoOutput(true);
    	 	httpConnection.setRequestProperty  ("Authorization", "Basic "+encoded);
        	 	//String urlParameters = "{\"channel\": \"vmprovisioning\", \"text\": \"Welcome Agilent\"}";
        	 //	DataOutputStream wr = new DataOutputStream(httpConnection.getOutputStream());
        	 	//wr.writeBytes(urlParameters);
        		//wr.flush();
        		//wr.close();
                // Normally, instanceof would also be used to check the type.
                if( ! enableCertCheck ) {
                    setAcceptAllVerifier((HttpsURLConnection)httpConnection);
                }

                reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()), 1);

                char[] buf = new char[1024];
                int count = 0;
                while( -1 < (count = reader.read(buf)) ) {
                    sb.append(buf, 0, count);
                }
                System.out.println(sb.toString());
                reader.close();
            } catch (IOException ex) {
                System.out.println(ex);

                if( null != reader ) {
                    reader.close();
                }
            }
            return sb.toString();
        }
    
    public static String postRequest(URL url, boolean enableCertCheck,String sessionToken) throws Exception {
        BufferedReader reader = null;
        // Repeat several times to check persistence.
        System.out.println("Cert checking=["+(enableCertCheck?"enabled":"disabled")+"]");
       // for (int i = 0; i < 5; ++i) {
        StringBuilder sb = new StringBuilder();
            try {
            	String loginPassword = "vcuser@eiamfdm.com"+ ":" + "Tcs@1234";
            	String encoded = new sun.misc.BASE64Encoder().encode (loginPassword.getBytes());
                HttpURLConnection httpConnection = (HttpsURLConnection) url.openConnection();
                httpConnection.setRequestMethod("GET"); // PUT is another valid option
                httpConnection.setRequestProperty( "Content-Type", "application/json" );
        	 	httpConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
        	 	httpConnection.setDoOutput(true);
        	 	httpConnection.setRequestProperty("authorization", "Bearer "+sessionToken);
        	 	httpConnection.setRequestProperty  ("Authorization", "Basic "+encoded);
        	 	httpConnection.setRequestProperty  ("vmware-api-session-id", sessionToken);
        	 	//String urlParameters = "{\"channel\": \"vmprovisioning\", \"text\": \"Welcome Agilent\"}";
                // Normally, instanceof would also be used to check the type.
               //  DataOutputStream wr = new DataOutputStream(httpConnection.getOutputStream());
         	 	//wr.writeBytes(urlParameters);
         		//wr.flush();
         		//wr.close();
                if( ! enableCertCheck ) {
                    setAcceptAllVerifier((HttpsURLConnection)httpConnection);
                }

       	 	 reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()), 1);

                char[] buf = new char[1024];
                int count = 0;
                while( -1 < (count = reader.read(buf)) ) {
                    sb.append(buf, 0, count);
                }
                System.out.println(sb.toString());

                reader.close();

            } catch (IOException ex) {
                System.out.println(ex);

                if( null != reader ) {
                    reader.close();
                }
            }
            return sb.toString();
        }
    
    
    
  //  }

    /**
     * Overrides the SSL TrustManager and HostnameVerifier to allow
     * all certs and hostnames.
     * WARNING: This should only be used for testing, or in a "safe" (i.e. firewalled)
     * environment.
     * 
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    protected static void setAcceptAllVerifier(HttpsURLConnection connection) throws NoSuchAlgorithmException, KeyManagementException {

        // Create the socket factory.
        // Reusing the same socket factory allows sockets to be
        // reused, supporting persistent connections.
        if( null == sslSocketFactory) {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, ALL_TRUSTING_TRUST_MANAGER, new java.security.SecureRandom());
            sslSocketFactory = sc.getSocketFactory();
        }

        connection.setSSLSocketFactory(sslSocketFactory);

        // Since we may be using a cert with a different name, we need to ignore
        // the hostname as well.
        connection.setHostnameVerifier(ALL_TRUSTING_HOSTNAME_VERIFIER);
    }

    private static final TrustManager[] ALL_TRUSTING_TRUST_MANAGER = new TrustManager[] {
        new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
        }
    };

    private static final HostnameVerifier ALL_TRUSTING_HOSTNAME_VERIFIER  = new HostnameVerifier() {
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    };

}