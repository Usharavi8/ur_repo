package com.vm.bean;
 
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.vmware.vim25.ClusterResourceUsageSummary;
import com.vmware.vim25.InvalidProperty;
import com.vmware.vim25.RuntimeFault;
import com.vmware.vim25.mo.ClusterComputeResource;
import com.vmware.vim25.mo.Datastore;
import com.vmware.vim25.mo.Folder;
import com.vmware.vim25.mo.HostSystem;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.ServiceInstance;
 
public class t1 {
 
    public static void main(String[] args) throws Exception {
    
    	  
    		  String SERVER_NAME = "10.134.95.11";
    		  String USER_NAME = "vcuser@eiamfdm.com";
    		  String PASSWORD = "Tcs@1234";
    		  /*String SERVER_NAME = "10.134.95.60";
    		  String USER_NAME = "administrator@vsphere.local";
    		  String PASSWORD = "Tcs@1234";*/

    			String url = "https://" + SERVER_NAME + "/sdk/vimService";
    			// List host systems
    			ClusterComputeResource cluster = null;
    			try {
    				ServiceInstance si = new ServiceInstance(new URL(url), USER_NAME, PASSWORD, true);
    				Folder rootFolder = si.getRootFolder();
    				 ManagedEntity[] clusterEntities = new InventoryNavigator(si.getRootFolder()).searchManagedEntities("ClusterComputeResource");
    				 //System.out.println(clusterEntities);
    				//ManagedEntity[] managedEntities=si.getRootFolder().getChildEntity();
    				for (ManagedEntity clusterEnt : clusterEntities) {
    					System.out.println(clusterEnt);
    					ClusterComputeResource name= (ClusterComputeResource) clusterEnt;
    					System.out.println("Cluster Name ::"+name.getName());
    					cluster = (ClusterComputeResource) new InventoryNavigator(rootFolder).searchManagedEntity("ClusterComputeResource",name.getName());
    					HostSystem[] host=cluster.getHosts();
    					for(HostSystem hs:host){
    						System.out.println("Host Name:"+hs.getName());
    						System.out.println("Host IP:"+hs.getConfig().getHost());
    					}
    					Datastore[] datastores=cluster.getDatastores();
    					for (Datastore ds : datastores) {
    						System.out.println("DS Name::"+ds.getName());
    					}
        				System.out.println();
        				System.out.println("Resource Usagae Summary for cluster::"+cluster.getName());
        				//Get the Cluster resource summary object
        				ClusterResourceUsageSummary resourceSummary= cluster.getResourceUsage();
        				System.out.println("CPU Capacity::"+(resourceSummary.getCpuCapacityMHz()/1000)+" GHz");
        			    int GHzFreeMemory = (resourceSummary.getCpuCapacityMHz()/1000)-(resourceSummary.getCpuUsedMHz()/1000); // result in GHz
        			    System.out.println("CPU Free Space Available::"+GHzFreeMemory);
        				System.out.println("Memory Capacity::"+resourceSummary.getMemCapacityMB()/1024+" GB");
        				System.out.println("Memory used::"+resourceSummary.getMemUsedMB()/1024+" GB");
        				int MemFreeSpace=(resourceSummary.getMemCapacityMB()/1024)-(resourceSummary.getMemUsedMB()/1024);
        				System.out.println("Free Memory:"+MemFreeSpace);
        				long diskSpaceGB=(resourceSummary.getStorageCapacityMB()/1024)-(resourceSummary.getStorageUsedMB()/1024);
        				System.out.println("disk space::"+diskSpaceGB);
        				System.out.println("Storage Capacity::"+(resourceSummary.getStorageCapacityMB()/1024)/1024+" TB");
        				System.out.println("Storage used::"+(resourceSummary.getStorageUsedMB()/1024)/1024+" TB");
        				long DiskFreeSpace=(resourceSummary.getStorageCapacityMB()/1024/1024)-(resourceSummary.getStorageUsedMB()/1024/1024);
        				System.out.println("Free Disk: "+DiskFreeSpace);
        				
        				
        				DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

        			    Date date = new Date();
        		        System.out.println(sdf.format(date));
        				
        				
    				}

    				//ClusterComputeResource cluster = null;
    				/*cluster = (ClusterComputeResource) new InventoryNavigator(rootFolder).searchManagedEntity("ClusterComputeResource", "MFDM-ProdCluster");

    				System.out.println();
    				System.out.println("Resource Usagae Summary for cluster::"+cluster.getName());
    				//Get the Cluster resource summary object
    				ClusterResourceUsageSummary resourceSummary= cluster.getResourceUsage();
    				System.out.println("CPU Capacity::"+resourceSummary.getCpuCapacityMHz()+" MHz");
    				System.out.println("CPU used::"+resourceSummary.getCpuUsedMHz()+" MHz");
    				System.out.println("Memory Capacity::"+resourceSummary.getMemCapacityMB()+" MB");
    				System.out.println("Memory used::"+resourceSummary.getMemUsedMB()+" MB");
    				System.out.println("Storage Capacity::"+resourceSummary.getStorageCapacityMB()+" MB");
    				System.out.println("Storage used::"+resourceSummary.getStorageUsedMB()+" MB");*/
    				si.getServerConnection().logout();
    				/* ManagedEntity[] managedEntities = new InventoryNavigator(si.getRootFolder()).searchManagedEntities("HostSystem");
    				for (ManagedEntity managedEntity : managedEntities) {
    					HostSystem host = (HostSystem) managedEntity;
    					System.out.println("Host: '" + host.getName() + "'");
    					HostHardwareInfo hw = host.getHardware();
    					System.out.println("Model: " + hw.getSystemInfo().getModel());
    					System.out.println("Memory in Bytes: " + hw.getMemorySize());
    					System.out.println("# of CPU Cores: " + hw.getCpuInfo().getNumCpuCores());
    					System.out.println("CPU Memory::"+hw.getCpuInfo().getHz());
    					HostCpuPackage[] cpuPkg = hw.getCpuPkg();
    					for (int i = 0; i < cpuPkg.length; i++) {
    						HostCpuPackage pkg = cpuPkg[i];
    						System.out.println(pkg.getIndex() + " : " + pkg.getDescription() + " (vendor: " + pkg.getVendor() + ")");
    					}
    				}*/
    				si.getServerConnection().logout();
    			} catch (InvalidProperty e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (RuntimeFault e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (RemoteException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			} catch (MalformedURLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		}
    	}
/*  if(args.length!=3)
{
    System.out.println("Usage: GetClusterResourceUsage url username password");
   // System.exit(-1);
}

URL url = null;
try
{ 
    url = new URL("https://10.134.95.11/"); 
} catch ( MalformedURLException urlE)
{
    System.out.println("The URL provided is NOT valid. Please check it...");
    System.exit(-1);
}
String username = "vcuser@eiamfdm.com";
String password = "Tcs@1234";
String ClusterName = "MFDM-ProdCluster"; //Your cluster Name

// Initialize the system, set up web services
ServiceInstance si = new ServiceInstance(url, username,
        password, true);
Folder rootFolder = si.getRootFolder();

ClusterComputeResource cluster = null;
cluster = (ClusterComputeResource) new InventoryNavigator(rootFolder)
.searchManagedEntity("ClusterComputeResource", ClusterName);

System.out.println();
System.out.println("Resource Usagae Summary for cluster::"+cluster.getName());
//Get the Cluster resource summary object
ClusterResourceUsageSummary resourceSummary= cluster.getResourceUsage();
System.out.println("CPU Capacity::"+resourceSummary.getCpuCapacityMHz()+" MHz");
System.out.println("CPU used::"+resourceSummary.getCpuUsedMHz()+" MHz");
System.out.println("Memory Capacity::"+resourceSummary.getMemCapacityMB()+" MB");
System.out.println("Memory used::"+resourceSummary.getMemUsedMB()+" MB");
System.out.println("Storage Capacity::"+resourceSummary.getStorageCapacityMB()+" MB");
System.out.println("Storage used::"+resourceSummary.getStorageUsedMB()+" MB");
si.getServerConnection().logout();
}*/
