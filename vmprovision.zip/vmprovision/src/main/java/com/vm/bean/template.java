package com.vm.bean;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import com.vmware.vim25.CustomizationAdapterMapping;
import com.vmware.vim25.CustomizationFixedIp;
import com.vmware.vim25.CustomizationFixedName;
import com.vmware.vim25.CustomizationGlobalIPSettings;
import com.vmware.vim25.CustomizationGuiUnattended;
import com.vmware.vim25.CustomizationIPSettings;
import com.vmware.vim25.CustomizationIdentification;
import com.vmware.vim25.CustomizationLinuxOptions;
import com.vmware.vim25.CustomizationLinuxPrep;
import com.vmware.vim25.CustomizationNetBIOSMode;
import com.vmware.vim25.CustomizationSpec;
import com.vmware.vim25.CustomizationSysprep;
import com.vmware.vim25.CustomizationUserData;
import com.vmware.vim25.CustomizationWinOptions;
import com.vmware.vim25.VirtualMachineCloneSpec;
import com.vmware.vim25.VirtualMachineRelocateSpec;
import com.vmware.vim25.mo.ClusterComputeResource;
import com.vmware.vim25.mo.Folder;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ServiceInstance;
import com.vmware.vim25.mo.Task;
import com.vmware.vim25.mo.VirtualMachine;

/**
 * Description: Demonstrates the workflow to deploy an OVF library item to a
 * resource pool.
 *
 * Author: VMware, Inc.
 * Sample Prerequisites: The sample needs an existing OVF
 * library item and an existing cluster with resources for creating the VM."
 *
 */
public class template {

	  public static void main(String args[]) throws MalformedURLException,
      RemoteException, InterruptedException {
		  String SERVER_NAME = "10.134.95.11";
		  String USER_NAME = "vcuser@eiamfdm.com";
		  String PASSWORD = "Tcs@1234";

			String url = "https://" + SERVER_NAME + "/sdk/vimService";
			// List host systems
			ClusterComputeResource cluster = null;

  String templateVMName = "tcsmfdm_twin10";
  String cloneName = "vm";

  //Connect to vSphere server using VIJAVA
	ServiceInstance si = new ServiceInstance(new URL(url), USER_NAME, PASSWORD, true);

  //Find the template machine in the inventory
  InventoryNavigator inventoryNavigator = new InventoryNavigator(si.getRootFolder());
  VirtualMachine vmTemplate = (VirtualMachine) inventoryNavigator.
          searchManagedEntity("VirtualMachine", templateVMName);

  //Create customization for cloning process(Uncomment the one you need)
  VirtualMachineCloneSpec cloneSpec = createLinuxCustomization();
  //VirtualMachineCloneSpec cloneSpec = createWindowsCustomization();
  //Do the cloning - providing the clone specification
  Task cloneTask = vmTemplate.cloneVM_Task((Folder) vmTemplate.getParent(),cloneName,cloneSpec);
  cloneTask.waitForTask();

  //Here is our new customized virtual machine ready
  VirtualMachine vm = (VirtualMachine) inventoryNavigator.searchManagedEntity("VirtualMachine", cloneName);
  vm.powerOnVM_Task(null).waitForTask();
}

public static VirtualMachineCloneSpec createLinuxCustomization(){
  VirtualMachineCloneSpec vmCloneSpec = new VirtualMachineCloneSpec();

  //Set location of clone to be the same as template (Datastore)
  vmCloneSpec.setLocation(new VirtualMachineRelocateSpec());

  //Clone is not powered on, not a template.
  vmCloneSpec.setPowerOn(false);
  vmCloneSpec.setTemplate(false);

  //Create customization specs/linux specific options
  CustomizationSpec customSpec = new CustomizationSpec();
  CustomizationLinuxOptions linuxOptions = new CustomizationLinuxOptions();
  customSpec.setOptions(linuxOptions);

  CustomizationLinuxPrep linuxPrep = new CustomizationLinuxPrep();
  linuxPrep.setDomain("tcsmfdm.com");
  linuxPrep.setHwClockUTC(true);
  linuxPrep.setTimeZone("Asia/Kolkata");

  CustomizationFixedName fixedName = new CustomizationFixedName();
  fixedName.setName("10.134.95.8");
  linuxPrep.setHostName(fixedName);
  customSpec.setIdentity(linuxPrep);

  //Network related settings
  CustomizationGlobalIPSettings globalIPSettings = new CustomizationGlobalIPSettings();
  globalIPSettings.setDnsServerList(new String[]{"8.8.8.8", "8.8.4.4"});
  globalIPSettings.setDnsSuffixList(new String[]{"search.com","my.search.com"});
  customSpec.setGlobalIPSettings(globalIPSettings);

  CustomizationFixedIp fixedIp = new CustomizationFixedIp();
  fixedIp.setIpAddress("192.168.10.1");

  CustomizationIPSettings customizationIPSettings = new CustomizationIPSettings();
  customizationIPSettings.setIp(fixedIp);
  customizationIPSettings.setGateway(new String[]{"192.168.1.1"});
  customizationIPSettings.setSubnetMask("255.255.0.0");

  CustomizationAdapterMapping adapterMapping = new CustomizationAdapterMapping();
  adapterMapping.setAdapter(customizationIPSettings);

  CustomizationAdapterMapping[] adapterMappings = new CustomizationAdapterMapping[]{adapterMapping};
  customSpec.setNicSettingMap(adapterMappings);

  //Set all customization to clone specs
  vmCloneSpec.setCustomization(customSpec);
  return vmCloneSpec;
}

public static VirtualMachineCloneSpec createWindowsCustomization(){
  //Windows needs valid product key in order to create fully working clone. Otherwise you will get error message
  //when machine is cloned
  String productID="XXXXX-XXXXX-XXXXXX-XXXXX";

  VirtualMachineCloneSpec cloneSpec = new VirtualMachineCloneSpec();

  //Set location of clone to be the same as template (Datastore)
  cloneSpec.setLocation(new VirtualMachineRelocateSpec());

  //Clone is not powered on, not a template.
  cloneSpec.setPowerOn(false);
  cloneSpec.setTemplate(false);

  //Create customization specs/win specific options
  //Windows are using SYSPREP for these kind of stuff
  CustomizationSpec customSpec = new CustomizationSpec();
  CustomizationWinOptions winOptions = new CustomizationWinOptions();

  winOptions.setChangeSID(true);
  //We don't want our preconfigured users to be deleted
  winOptions.setDeleteAccounts(false);

  customSpec.setOptions(winOptions);
  CustomizationSysprep sprep = new CustomizationSysprep();

  CustomizationGuiUnattended guiUnattended = new CustomizationGuiUnattended();
  guiUnattended.setAutoLogon(false);
  guiUnattended.setAutoLogonCount(0);
  guiUnattended.setTimeZone(4);
  sprep.setGuiUnattended(guiUnattended);

  CustomizationIdentification custIdent = new CustomizationIdentification();
  custIdent.setJoinWorkgroup("WORKGROUP");
  sprep.setIdentification(custIdent);

  CustomizationUserData custUserData = new CustomizationUserData();
  CustomizationFixedName fixedName = new CustomizationFixedName();
  fixedName.setName("windows-clone");

  //set from cloned machine
  custUserData.setProductId(productID);     // REQUIRED FOR Windows
  custUserData.setComputerName(fixedName);
  custUserData.setFullName("windows-clone.example.com");
  custUserData.setOrgName("example.com");

  sprep.setUserData(custUserData);
  customSpec.setIdentity(sprep);

  //Network related settings
  CustomizationGlobalIPSettings globalIPSettings = new CustomizationGlobalIPSettings();
  globalIPSettings.setDnsServerList(new String[]{"8.8.8.8","8.8.4.4"});
  globalIPSettings.setDnsSuffixList(new String[]{"example.com"});

  customSpec.setGlobalIPSettings(globalIPSettings);
  CustomizationFixedIp fixedIp = new CustomizationFixedIp();
  fixedIp.setIpAddress("192.168.10.2");

  CustomizationIPSettings customizationIPSettings = new CustomizationIPSettings();
  customizationIPSettings.setIp(fixedIp);
  customizationIPSettings.setGateway(new String[]{"192.168.1.1"});
  customizationIPSettings.setSubnetMask("255.255.0.0");

  //Disabling netBIOS
  customizationIPSettings.setNetBIOS(CustomizationNetBIOSMode.disableNetBIOS);
  customizationIPSettings.setDnsDomain("example.com");

  CustomizationAdapterMapping adapterMapping = new CustomizationAdapterMapping();
  adapterMapping.setAdapter(customizationIPSettings);

  CustomizationAdapterMapping[] adapterMappings = new CustomizationAdapterMapping[]{adapterMapping};
  customSpec.setNicSettingMap(adapterMappings);

  //Set all customization to clone specs
  cloneSpec.setCustomization(customSpec);

  return cloneSpec;
}
}
