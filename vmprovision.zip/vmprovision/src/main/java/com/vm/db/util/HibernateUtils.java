package com.vm.db.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public final class HibernateUtils {
public static SessionFactory factory=null;
public static Session session=null;
static {
		factory=new Configuration().configure("/com/vm/cfg/hibernate.cfg.xml").buildSessionFactory();
}
public static Session getSession(){
	return session=factory.openSession();
}
public static void closeSession(Session close_session){
	close_session.close();
}
public static void closeSessionFactory(){
	factory.close();
}

}
