package com.vm.db.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.vm.controller.VMProvision;

public class CommonUtils {
	Logger log=Logger.getLogger(VMProvision.class);
    private static SSLSocketFactory sslSocketFactory = null;
	
	public int postRequest(String slackUrl,String token,String text) {
		int responseCode =0;
		try {
		URL url = new URL(slackUrl);
	 	URLConnection con = url.openConnection();
	 	HttpURLConnection http = (HttpURLConnection)con;
	 	http.setRequestMethod("POST"); // PUT is another valid option
	 	http.setRequestProperty( "Content-Type", "application/json" );
	 	http.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
		http.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		String urlParameters = "{\"channel\": \"vmprovisioning\", \"text\": \""+text+"\"}";
		// Send post request
		http.setDoOutput(true);
		http.setRequestProperty  ("Authorization", "Bearer " + token);
		System.out.println("Bearer " + token);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(urlParameters);
		wr.flush();
		wr.close();

		 responseCode = http.getResponseCode();
		log.info("\nSending 'POST' request to URL : " + url+", Post parameters : " + urlParameters + " Response Code : " + responseCode);
	/*	BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		in.close();
		}*/
		
		//print result
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error Occurs in Slack Api:"+e.getMessage());
	}
	 	
	 return responseCode;
	 	
	 	
	}
	
	public int postSlackPython(String text) {
		int responseCode =0;String postData="",api="";
		try {
		 URL url = null;
         HttpURLConnection httpUrlCon = null;
 		String respStr = null;
 		if(text.contains("template")){
 			postData="{\"data\":  "+text+"}";
 			api="http://10.134.95.137:7070/create_vm";
 		}else{
 			postData="{\"data\":  \""+text+"\"}";
 			api="http://10.134.95.137:8080/get_data";
 		}
long t = System.currentTimeMillis();
url = new URL(api);
httpUrlCon = (HttpURLConnection) url.openConnection();
httpUrlCon.setRequestProperty("Content-Type", "application/json");
httpUrlCon.setDoInput(true);
httpUrlCon.setDoOutput(true);
httpUrlCon.setConnectTimeout(75000);
httpUrlCon.setReadTimeout(75000);
httpUrlCon.setRequestMethod("POST");
IOUtils.write(postData, httpUrlCon.getOutputStream());
responseCode=httpUrlCon.getResponseCode();
respStr = IOUtils.toString(httpUrlCon.getInputStream());
//logger.info("URL "+targetUrl+" REQUESRT XML "+postData); 
//logger.info("Response time :: "+(System.currentTimeMillis()-t)+" ms");
System.out.println("URL \n REQUESRT XML "+postData+"\nRESPONSE XML"+respStr);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error Occurs in Slack Api:"+e.getMessage());
	}
		return responseCode;
	}
	
	 public static String postVcenterRequest(String api, boolean enableCertCheck,String sessionToken,String method,String authToken) throws Exception {
	        BufferedReader reader = null;
	        String code="";
	        // Repeat several times to check persistence.
	        System.out.println("Cert checking=["+(enableCertCheck?"enabled":"disabled")+"]");
	       // for (int i = 0; i < 5; ++i) {
	        StringBuilder sb = new StringBuilder();
	            try {
	            	//String loginPassword = "administrator@vsphere.local"+ ":" + "Tcs@1234";
	            	//String encoded = new sun.misc.BASE64Encoder().encode (loginPassword.getBytes());
	            	URL url = new URL(api);
	                HttpURLConnection httpConnection = (HttpsURLConnection) url.openConnection();
		            httpConnection.setRequestMethod(method); // PUT is another valid option
	                httpConnection.setRequestProperty( "Content-Type", "application/json" );
	        	 	httpConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
	        	 	httpConnection.setDoInput(true);
	        	 	httpConnection.setDoOutput(true);
	        	 	if(!sessionToken.equalsIgnoreCase("null") && !sessionToken.equals("")) {
	        	 	httpConnection.setRequestProperty  ("Authorization", "Basic "+authToken);//+encoded);
	        	 	httpConnection.setRequestProperty  ("vmware-api-session-id", sessionToken);
	        	 	}else {
		        	 	httpConnection.setRequestProperty  ("Authorization", "Basic "+authToken);//+encoded);
	        	 	}
	                // Normally, instanceof would also be used to check the type.
	                if( ! enableCertCheck ) {
	                    setAcceptAllVerifier((HttpsURLConnection)httpConnection);
	                }
	                if(method.equalsIgnoreCase("DELETE")) {
	                	code=String.valueOf(httpConnection.getResponseCode());
	                }else {
	                reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()), 1);
	                char[] buf = new char[1024];
	                int count = 0;
	                while( -1 < (count = reader.read(buf)) ) {
	                    sb.append(buf, 0, count);
	                }
	                System.out.println(sb.toString());

	                reader.close();
	                }
	            } catch (IOException ex) {
	                System.out.println(ex);

	                if( null != reader ) {
	                    reader.close();
	                }
	            }
	            return sb.toString();
	        }
	
	
	 protected static void setAcceptAllVerifier(HttpsURLConnection connection) throws NoSuchAlgorithmException, KeyManagementException {

	        // Create the socket factory.
	        // Reusing the same socket factory allows sockets to be
	        // reused, supporting persistent connections.
	        if( null == sslSocketFactory) {
	            SSLContext sc = SSLContext.getInstance("SSL");
	            sc.init(null, ALL_TRUSTING_TRUST_MANAGER, new java.security.SecureRandom());
	            sslSocketFactory = sc.getSocketFactory();
	        }

	        connection.setSSLSocketFactory(sslSocketFactory);

	        // Since we may be using a cert with a different name, we need to ignore
	        // the hostname as well.
	        connection.setHostnameVerifier(ALL_TRUSTING_HOSTNAME_VERIFIER);
	    }

	    private static final TrustManager[] ALL_TRUSTING_TRUST_MANAGER = new TrustManager[] {
	        new X509TrustManager() {
	            public X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
	        }
	    };

	    private static final HostnameVerifier ALL_TRUSTING_HOSTNAME_VERIFIER  = new HostnameVerifier() {
	        public boolean verify(String hostname, SSLSession session) {
	            return true;
	        }
	    };

}
