package com.vm.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Random;
import java.util.Scanner;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.vm.dao.DormantIdentifier;
import com.vm.db.util.CommonUtils;
import com.vm.utils.PropertyReader;
import com.vmware.vim25.ClusterResourceUsageSummary;
import com.vmware.vim25.InvalidProperty;
import com.vmware.vim25.RuntimeFault;
import com.vmware.vim25.mo.ClusterComputeResource;
import com.vmware.vim25.mo.Folder;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.ServiceInstance;

/**
 * Root resource (exposed at "myresource" path)
 */
@Path("/vcenter")
public class VMProvision {
	Logger log=Logger.getLogger(VMProvision.class);
	String slackUrl="";
	String slackToken="";
 	String text="";
    private static SSLSocketFactory sslSocketFactory = null;

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     * @throws IOException 
     */
/*Slack API
Url			: https://slack.com/api/chat.postMessage
Method		: POST
Headers
content-type	: application/json
authorization	: Bearer xoxb-579428186150-629275123446-KittuPVN8tnszEfM4ZvHHXdV
Body 
{"channel": "vmprovisioning", "text": "test"}
*/

	@POST
    @Path("/dormant")
    @Produces(MediaType.APPLICATION_JSON)//@Context HttpServletRequest request,@Context HttpServletResponse response
	@Consumes(MediaType.APPLICATION_JSON)
    public String SOPfinder(@Context HttpServletRequest request,@Context HttpServletResponse response) throws IOException {
		//{"type" : "silver","ram" : "2 GB","cpu" :"2","hdd" : "40 GB","conversationid" : "gbh4a25ama8" ,"name" : "User","channelid" : "emulator","ticketno" : "INC0026663"}		
		String mailId="",empName="",empMail="",desc="",date="",gl_id="",gl_mail="",req_for="",days="";
		String msg="";
		String mailSubject="",vcenterRestApi="",json="",authToken="",sessionToken="";
			String value="{\"status\":\"Received\"}";	
			String category="",conversationId="",ticketId="",channelId="";
		try {
			mailSubject=PropertyReader.readProperties("EMAIL_SUBJECT");
			mailId=PropertyReader.readProperties("USER_MAIL_ID");
		slackUrl=PropertyReader.readProperties("SLACK_URL");
		slackToken=PropertyReader.readProperties("SLACK_AUTH_TOKEN");
		 BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));
		 String status="",vmDetails="",userName="",memory="",cpu="",diskSpace="",type="";
		// int cpu=0,diskSpace=0;
		 	log.debug("Hi Am Dormant Identifier..");
		 	if (br != null) {
		      vmDetails = br.readLine();
		      System.out.println(vmDetails.toString());
		      log.info(vmDetails.toString());
		 	}
		 	if(vmDetails.contains("hdd")) {
		try {
			JSONObject obj = new JSONObject(vmDetails.toString());
			userName=obj.getString("name");
			cpu=obj.getString("cpu");
			memory=obj.getString("ram");
			diskSpace=obj.getString("hdd");
			type=obj.getString("type");
			conversationId=obj.getString("conversationid");
			ticketId=obj.getString("ticketno");
			channelId=obj.getString("channelid");
			if(!type.equalsIgnoreCase("silver")){
			empName=obj.getString("emp_name");
			empMail=obj.getString("emp_email");
			desc=obj.getString("description");
			date=obj.getString("date");
			gl_id=obj.getString("gl_id");
			gl_mail=obj.getString("gl_mail");
			req_for=obj.getString("required_for");
			days=obj.getString("days");
			}
			category=obj.getString("category");
		} catch (JSONException e){
			e.printStackTrace();
		}
		//new CommonUtils().postRequest(slackUrl,slackToken,PropertyReader.readProperties("VM_TICKET_MSG").replace("{0}",ticketId));
		
		 	if(memory != "" && cpu != "" && diskSpace != "") {
		 		try {
		 			if(type.equalsIgnoreCase("gold") || type.equalsIgnoreCase("platinum")){
		 				new CommonUtils().postSlackPython(PropertyReader.readProperties("VM_INITIAL_MSG"));
		 				new CommonUtils().postSlackPython(PropertyReader.readProperties("VM_TICKET_MSG").replace("{0}",ticketId));
		 				//new CommonUtils().postRequest(slackUrl,slackToken,PropertyReader.readProperties("VM_GOLD(OR)PLATINUM_MSG"));
		 				new CommonUtils().postSlackPython(PropertyReader.readProperties("VM_GOLD(OR)PLATINUM_MSG"));
		 				Thread.sleep(5000);
				 		//new CommonUtils().postRequest(slackUrl,slackToken,PropertyReader.readProperties("VM_INITIAL_MSG"));
		 				//new CommonUtils().postSlackPython(PropertyReader.readProperties("VM_INITIAL_MSG"));
		 			}else {
			 		//new CommonUtils().postRequest(slackUrl,slackToken,PropertyReader.readProperties("VM_INITIAL_MSG"));
		 				//new CommonUtils().postSlackPython("Dormant Process starts...");
		 			}
			 		} catch (MalformedURLException e) {
			            e.printStackTrace();
			        } catch (IOException e) {
			            e.printStackTrace();
			        }		
		 		if(type.equalsIgnoreCase("silver") && category.equalsIgnoreCase("Dormant")){
		 		status=new DormantIdentifier().dormantDetails(memory, cpu, diskSpace, userName,category,ticketId,conversationId,channelId,empName,empMail,desc,date,gl_id,gl_mail,req_for,days);
		 		}else{
		 			status="Not Available";
		 		}
		 	if(status.equalsIgnoreCase("available")){
		 		new CommonUtils().postSlackPython("Dormant Process starts...");
		 		Thread.sleep(10000);
	//new CommonUtils().postRequest(slackUrl,slackToken,PropertyReader.readProperties("VM_DORMANT_MSG"));
	//new CommonUtils().postSlackPython(PropertyReader.readProperties("VM_DORMANT_MSG"));
		 		new CommonUtils().postSlackPython("We found Dormant VM's,We sent mail notification to the dormant user");
		 		Random random = new Random(); 
		 	    String dormantId = String.format("%04d", random.nextInt(10000));
		 		msg=PropertyReader.readProperties("EMAIL_BODY");
		 		msg=msg.replace("{0}", dormantId);
		 		msg=msg.replace("{1}", "test_vm");
		 		new EmailServiceImpl().sendMail(msg, mailId, mailSubject);
		 		//mail has to be sent
		 	}else if(status.equalsIgnoreCase("Not Available")){
				//new CommonUtils().postSlackPython("Dormant process cleared the Idle VM storage memory and added to Vcenter resource POOL ...! ");
				//Thread.sleep(10000);
				new CommonUtils().postSlackPython("Checking space in Resource Pool...");
		 		String clustName="";
		 		//need to check Resource Pool
		 		String SERVER_NAME = "10.134.95.11";
	    		  String USER_NAME = "vcuser@eiamfdm.com";
	    		  String PASSWORD = "Tcs@1234";

	    			String url = "https://" + SERVER_NAME + "/sdk/vimService";
	    			// List host systems
	    			ClusterComputeResource cluster = null;
	    			try {
	    				ServiceInstance si = new ServiceInstance(new URL(url), USER_NAME, PASSWORD, true);
	    				Folder rootFolder = si.getRootFolder();
	    				 ManagedEntity[] clusterEntities = new InventoryNavigator(si.getRootFolder()).searchManagedEntities("ClusterComputeResource");
	    				for (ManagedEntity clusterEnt : clusterEntities) {
	    					System.out.println(clusterEnt);
	    					ClusterComputeResource name= (ClusterComputeResource) clusterEnt;
	    					System.out.println("Cluster Name ::"+name.getName());
	    					cluster = (ClusterComputeResource) new InventoryNavigator(rootFolder).searchManagedEntity("ClusterComputeResource",name.getName() );
	        				clustName=cluster.getName();
	        				//Get the Cluster resource summary object
	        				if(clustName.equalsIgnoreCase("MFDM-ProdCluster")){
	        					/*Thread.sleep(5000);
	        					new CommonUtils().postSlackPython("There is no space available in *MFDM-ProdCluster*, Please be patient, we are checking in another cluster...");*/
	        				}
	        				if(clustName.equalsIgnoreCase("MFDM-InfraCluster")){
	        					Thread.sleep(5000);
	        					new CommonUtils().postSlackPython("There is no space available in *MFDM-ProdCluster*, Please be patient, we are checking in another cluster...");
	        				ClusterResourceUsageSummary resourceSummary= cluster.getResourceUsage();
	        				int GHzFreeMemory = (resourceSummary.getCpuCapacityMHz()/1000)-(resourceSummary.getCpuUsedMHz()/1000); // result in GHz
	        			    System.out.println("CPU Free Space Available::"+GHzFreeMemory);
	        				int MemFreeSpace=(resourceSummary.getMemCapacityMB()/1024)-(resourceSummary.getMemUsedMB()/1024);
	        				System.out.println("Free Memory:"+MemFreeSpace);
	        				long diskSpaceGB=((resourceSummary.getStorageCapacityMB()/1024)-(resourceSummary.getStorageUsedMB()/1024));
	        				long DiskFreeSpace=((resourceSummary.getStorageCapacityMB()/1024)/1024)-((resourceSummary.getStorageUsedMB()/1024)/1024);
	        				System.out.println("Free Disk: "+DiskFreeSpace);
	        				if(MemFreeSpace > 4 && diskSpaceGB > 40){
	        					System.out.println("Free Space Available in Resource Pool");
	        					new CommonUtils().postSlackPython("Thanks for your patience, We great to inform you that we found free space in - *MFDM-InfraCluster*, your request is in progress...");
	        					Thread.sleep(15000);
	        					new CommonUtils().postSlackPython("Request raised for New VM Successfully, We will confirm through the mail shortly .....! ");
	        					mailId=PropertyReader.readProperties("ADMIN_MAIL_ID");
	        					msg=PropertyReader.readProperties("EMAIL_BODY_ADMIN_PROVISIONING");
	        					msg=msg.replace("{0}", memory);
	        					msg=msg.replace("{1}", cpu);
	        					msg=msg.replace("{2}", diskSpace);
	        					msg=msg.replace("{3}", ticketId);
	        					mailSubject=PropertyReader.readProperties("EMAIL_SUBJECT_ADMIN_PROVISIONING");
	        			 		new EmailServiceImpl().sendMail(msg, mailId, mailSubject);
	        			 		Thread.sleep(5000);
	        					new CommonUtils().postSlackPython("*Note: It is for Admin, Today we decomissioned 2 VM's Successfully and resource pool memory increased by 0.2%.*");
	        					msg=PropertyReader.readProperties("EMAIL_BODY_ADMIN");
	        					mailSubject=PropertyReader.readProperties("EMAIL_SUBJECT_ADMIN");
	        			 		new EmailServiceImpl().sendMail(msg, mailId, mailSubject);

	        				}
	    				}
	    				}
	    				si.getServerConnection().logout();
	    			} catch (InvalidProperty e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			} catch (RuntimeFault e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			} catch (RemoteException e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			} catch (MalformedURLException e) {
	    				// TODO Auto-generated catch block
	    				e.printStackTrace();
	    			}
		 	}
		 }
		 	// return Response.ok().build();
		 	//vmDetails="{sender: Agilentsda@tmexchlab.com, messageId: AAMkADNlNTZmM2U4LThiZjYtNGYxZi1iM2UyLTFiYjQ2YzZiODg3OQBGAAAAAAC0UQOHK31bQq2J1yR32k0/BwD+zNxY+z72Rq4BYqyb1oszAAAAAAEMAAD+zNxY+z72Rq4BYqyb1oszAAAa/qDUAAA=, VM: DevPlusDB84110, approval: approved}";
		 	}else if(vmDetails.contains("approval") && vmDetails.contains("VM")){
		 		//{sender: vmuser1@mfdmlab.com, messageId: AAMkADNlNTZmM2U4LThiZjYtNGYxZi1iM2UyLTFiYjQ2YzZiODg3OQBGAAAAAAC0UQOHK31bQq2J1yR32k0/BwD+zNxY+z72Rq4BYqyb1oszAAAAAAEMAAD+zNxY+z72Rq4BYqyb1oszAAAa/qDUAAA=, VM: DevPlusDB84110,, approval: approved}
		 		JSONObject obj = new JSONObject(vmDetails.toString());
				userName=obj.getString("sender");
				cpu=obj.getString("messageId");
				memory=obj.getString("VM");
				diskSpace=obj.getString("approval");
				value=vmDetails;
				System.out.println(value);
				if(diskSpace.equals("approved")) {
		 		//new CommonUtils().postRequest(slackUrl,slackToken,PropertyReader.readProperties("VM_APPROVAL_MSG"));
 				//new CommonUtils().postSlackPython(PropertyReader.readProperties("VM_APPROVAL_MSG"));
				new CommonUtils().postSlackPython("We received approval mail from :"+userName+" for the VM :"+memory+",So we are proceeding to decomissioning.");
		 		vcenterRestApi=PropertyReader.readProperties("GET_CSI_SESSION_TOKEN");
		 		authToken=PropertyReader.readProperties("LOCAL_AUTHORIZATION_KEY");
		 		json=new CommonUtils().postVcenterRequest(vcenterRestApi, false, sessionToken,"POST",authToken);
		 		JSONObject obj1 = new JSONObject(json);
				sessionToken=obj1.getString("value");
			 	json=new CommonUtils().postVcenterRequest("https://10.134.95.11/rest/vcenter/vm/test_vm", false, sessionToken,"DELETE",authToken);
				System.out.println(sessionToken);
				if(sessionToken != "" && !sessionToken.isEmpty()) {
					vcenterRestApi=PropertyReader.readProperties("GET_LIST_VM");
					json=new CommonUtils().postVcenterRequest(vcenterRestApi, false, sessionToken,"GET",authToken);
			 		//new CommonUtils().postRequest(slackUrl,slackToken,"Request raised for New VM Successfully, You will confirmed by mail shortly ....! ");
					new CommonUtils().postSlackPython("Decomissioning for VM:"+memory+" with spec-4 GB RAM,4 vcpu's,40 GB HD done,Now we are notifying the Administrator..");
				}
		 	}
		 	}else if(vmDetails.contains("approval") && !vmDetails.contains("VM")){
		 		JSONObject obj = new JSONObject(vmDetails.toString());
				userName=obj.getString("sender");
				cpu=obj.getString("messageId");
				diskSpace=obj.getString("approval");
				if(diskSpace.equals("approved")) {
	 				new CommonUtils().postSlackPython("*Approval Notification: We got Approval mail from Infra Team for New VM creation...*");
					new CommonUtils().postSlackPython("{\"template\":\"TCSMFDM_TWIN10\",\"vmname\":\"vm-2019\"}");
				}
		 	}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		 	return value;
	}
	
	 @GET
	    @Path("/load")
	    @Produces(MediaType.APPLICATION_JSON)//@Context HttpServletRequest request,@Context HttpServletResponse response
	    public void emailDataLoading(@Context HttpServletRequest request,@Context HttpServletResponse response) throws Exception {
		 String code="";String line="",result="";
		 int status=0;
			 
		      //  URL url2=new URL("https://mfdm.tcseia.com:8443/aglBotService");
				URL url2 = new URL("https://10.134.95.60/rest/com/vmware/cis/session");

		        result= this.request(url2, false);
		        response.setContentType("text/html");
		        PrintWriter writer = response.getWriter();
		        writer.write("<h4>Session Token"+result+"</h4>");
		       // out.flush();

				/*String sessionToken=PropertyReader.readProperties("TOKEN_VALUE");
				String authToken=PropertyReader.readProperties("LOCAL_AUTHORIZATION_KEY");
				String vmList=PropertyReader.readProperties("GET_LIST_VM");
			SSLContext sslctx = SSLContext.getInstance("SSL");
			
			sslctx.init(null, new X509TrustManager[] { new MyTrustManager()
			}, null);

			HttpsURLConnection.setDefaultSSLSocketFactory(sslctx.getSocketFactory());
			URL url = new URL("https://10.134.95.60/rest/com/vmware/cis/session");
			System.out.println(url);
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.setDoOutput(true);
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty  ("Authorization", "Basic "+authToken);
			System.out.println("Authorization Coder:"+authToken);
			//con.setRequestProperty  ("Authorization", "Basic " + authToken);
			//con.setRequestProperty("value", sessionToken);
			//PrintStream ps = new PrintStream(con.getOutputStream());
			//ps.println("f1=abc&f2=xyz");
			//ps.close();
			con.connect();
			System.out.println(con.getResponseCode());
			BufferedReader br = new BufferedReader(new
					InputStreamReader(con.getInputStream()));
			if (con.getResponseCode() == HttpsURLConnection.HTTP_OK) {
			while((line = br.readLine()) != null) {
			System.out.println(line);
			status=con.getResponseCode();
			code="{code:"+con.getResponseCode()+",input:"+line+"}";
			System.out.println("Response"+code);
			 String json = null;
			 response.setCharacterEncoding("utf-8");
			 PrintWriter out = response.getWriter();
				if(line == "") {
					out.print("{\"code\":"+status+",\"status\":\"Testing Fail\",\"value\":\""+line+"\"}");
				}else {
				out.print(line);
				}
				out.flush();
			}
			}else {
				Scanner sc = new Scanner(url.openStream());
				while(sc.hasNext())
				{
				line+=sc.nextLine();
				}
				//System.out.println(“\nJSON data in string format”);
				System.out.println(line);
				sc.close();
			}
			br.close();
			con.disconnect();
			}catch(Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}*/
	 }

	 class MyTrustManager implements X509TrustManager {
			public void checkClientTrusted(X509Certificate[] chain, String
			authType) {
			}

			public void checkServerTrusted(X509Certificate[] chain, String
			authType) {
			}

			public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[0];
			}
			}
	 
	 public static String request(URL url, boolean enableCertCheck) throws Exception {
	        BufferedReader reader = null;
	        String line="";
	        // Repeat several times to check persistence.
	        System.out.println("Cert checking=["+(enableCertCheck?"enabled":"disabled")+"]");
	       // for (int i = 0; i < 5; ++i) {
	        StringBuilder sb = new StringBuilder();
	            try {

	                HttpURLConnection httpConnection = (HttpsURLConnection) url.openConnection();
	                httpConnection.setRequestMethod("POST"); // PUT is another valid option
	                httpConnection.setRequestProperty( "Content-Type", "application/json" );
	        	 	httpConnection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
	        	 	httpConnection.setDoOutput(true);
	        	 httpConnection.setRequestProperty  ("Authorization", "Basic RUlBTUZETVx2Y3VzZXI6VGNzQDEyMzQ1Ng==");
	        	 	//String urlParameters = "{\"summary\":[\"Install Software\"]}";
	        	 	
	        	 	//DataOutputStream wr = new DataOutputStream(httpConnection.getOutputStream());
	        	 	//wr.writeBytes(urlParameters);
	        		//wr.flush();
	        		//wr.close();
	                // Normally, instanceof would also be used to check the type.
	                if( ! enableCertCheck ) {
	                    setAcceptAllVerifier((HttpsURLConnection)httpConnection);
	                }
	                if(httpConnection.getResponseCode()==200) {
	                reader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()), 1);
	                }else {
	    				Scanner sc = new Scanner(url.openStream());
	    				while(sc.hasNext())
	    				{
	    				line+=sc.nextLine();
	    				}
	    				//System.out.println(“\nJSON data in string format”);
	    				System.out.println(line);
	    				sc.close();
	    			}
	                char[] buf = new char[1024];
	                int count = 0;
	                while( -1 < (count = reader.read(buf)) ) {
	                    sb.append(buf, 0, count);
	                }
	                System.out.println(sb.toString());

	                reader.close();

	            } catch (IOException ex) {
	                System.out.println(ex);

	                if( null != reader ) {
	                    reader.close();
	                }
	            }
	            return sb.toString();
	        }
	 
	 protected static void setAcceptAllVerifier(HttpsURLConnection connection) throws NoSuchAlgorithmException, KeyManagementException {

	        // Create the socket factory.
	        // Reusing the same socket factory allows sockets to be
	        // reused, supporting persistent connections.
	        if( null == sslSocketFactory) {
	            SSLContext sc = SSLContext.getInstance("SSL");
	            sc.init(null, ALL_TRUSTING_TRUST_MANAGER, new java.security.SecureRandom());
	            sslSocketFactory = sc.getSocketFactory();
	        }

	        connection.setSSLSocketFactory(sslSocketFactory);

	        // Since we may be using a cert with a different name, we need to ignore
	        // the hostname as well.
	        connection.setHostnameVerifier(ALL_TRUSTING_HOSTNAME_VERIFIER);
	    }

	    private static final TrustManager[] ALL_TRUSTING_TRUST_MANAGER = new TrustManager[] {
	        new X509TrustManager() {
	            public X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
	        }
	    };

	    private static final HostnameVerifier ALL_TRUSTING_HOSTNAME_VERIFIER  = new HostnameVerifier() {
	        public boolean verify(String hostname, SSLSession session) {
	            return true;
	        }
	    };
}

