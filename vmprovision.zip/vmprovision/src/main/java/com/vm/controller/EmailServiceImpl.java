package com.vm.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.vm.bean.EmailInfo;
import com.vm.utils.PropertyReader;

import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet;
import microsoft.exchange.webservices.data.core.enumeration.misc.ExchangeVersion;
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.BodyType;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.enumeration.search.LogicalOperator;
import microsoft.exchange.webservices.data.core.service.folder.Folder;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.core.service.item.Item;
import microsoft.exchange.webservices.data.core.service.schema.EmailMessageSchema;
import microsoft.exchange.webservices.data.credential.ExchangeCredentials;
import microsoft.exchange.webservices.data.credential.WebCredentials;
import microsoft.exchange.webservices.data.property.complex.EmailAddress;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;
import microsoft.exchange.webservices.data.search.filter.SearchFilter;

public class EmailServiceImpl {
	Logger log=Logger.getLogger(EmailServiceImpl.class);
	String supportId="";
	String supportPwd="";
	String url="";
			
	private static ExchangeService service;
	public ExchangeService intantiateService() throws Exception {
		try {
			supportId=PropertyReader.readProperties("SUPPORT_ID");
		    supportPwd=PropertyReader.readProperties("SUPPORT_PWD");
		    url=PropertyReader.readProperties("EWS_URL");
					
		if(service==null) {
			service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
			service.setUrl(new URI(url));
			service.setTraceEnabled(true);
			ExchangeCredentials credentials = new WebCredentials(supportId, supportPwd);
			service.setCredentials(credentials);			
		}		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return service;
	}
	
	public MessageBody composeHtmlBody(String responseText) throws Exception {
		StringBuilder sb=new StringBuilder();
		sb.append("<!DOCTYPE html><html><body>");				
		sb.append("<p>").append(responseText.replace("\n", "<br>")).append("</p>"); 
		if(responseText.contains("Admin") && !responseText.contains("Specification's")){
		sb.append("<br><table border=1>").append("<tr><b><th>VM_Name</th><th>Memory</th><th>CPU</th><th>Disk Space</th></b></tr>");
		sb.append("<tr><td>WINS8467</td><td>6 GB</td><td>2</td><td>40 GB</td></tr>");
		sb.append("<tr><td>RHEL95133</td><td>8 GB</td><td>4</td><td>100 GB</td></tr>");
		sb.append("</table>");
		sb.append("<p>").append((PropertyReader.readProperties("EMAIL_ADMIN_SIGNATURE").replace("\n", "<br>"))).append("</p");
		}
/*		sb.append("<img alt=\"Logo\" src=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABICAYAAABMb8iNAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADKGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDAgNzkuMTYwNDUxLCAyMDE3LzA1LzA2LTAxOjA4OjIxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOCAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo1QjM3QTNCMDcxMDAxMUU4OTRFMDgyQjcyOEQzNjg1NSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo1QjM3QTNCMTcxMDAxMUU4OTRFMDgyQjcyOEQzNjg1NSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjVCMzdBM0FFNzEwMDExRTg5NEUwODJCNzI4RDM2ODU1IiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjVCMzdBM0FGNzEwMDExRTg5NEUwODJCNzI4RDM2ODU1Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+EKrWhwAAJ5FJREFUeF7tnQd8FMXbx3/pPRdS6R1BUERBQRAUARUEQQQFRETpvFIVhT/SO0pHREWliFRBqYrSlCIICCpdkB5C6l16f59nbpfsXu4ud5dLTHC/n88QZu5ub29259nneeaZZ1xyCWhoaGiUAlylvxoaGholHk1gaWholBo0gaWhoVFq0ASWhoZGqcG80z07AchNpP/8F+RZNv3MECp+Ur3wxMQnIiM9E66uLlKLZbj3PdzdEBoSKLU4h5u3Y+n76frR8d3cXBEeqpNesZ8bt2LgRuco/5rsnFyUDdPRcd2kFuukpmUglvrEnc6D4RsuKysblcqHirq9RN1JwO6Df+LSlduI1ycjhzoxWOePWtXKos2TDRAaHCC9s3BkZGRh1/6T+OPsVTr/JGRnZSFI54fqVcriqcfroXLFMOmdGsWFeYEV1Q2IX/ffkFc5VMrOBILeM9adQIuOY/HLziOAt6fUYgN0FbxDA/F8q4YYPeRFNHqopvSC/Zw+fx0P1HkFCAgyNpBw8C0bjKg/v4C/n4+xzUays3Pg7t4S9EG6W6RGJi0Trw1oj5WLhkkNlvl8zW707TGBzkcSynzLJSXTn5+NdRsZM/0rLFy2HSkksODjBbi7woWFMpGbQxcyi0pqGoIrRWDs8C4YOaCDeM1eNm47jPemrcLlPy7R93jT95CwpoePi4sLckhYU6fQ96TDK0SH4f3aY+bYntInNYoa8wIruj+g/+w/o2AhfCGgG2KsO4GOr8/Ezr0n4MuDykb4MvBgSCPNLCtGj6atG+Lg1unSq/bxysC52LT9V/j55n1/ckoaaQYROH9gsdRiK7lwieiMQNIseMDK8PkabkRj+fLReP1lEmhWWPvdAXTv+wF0wUaBJT6bkITcO9+KekGwkBo26mPAyxN+/t4kP6xrdqy9JZPm5UG/f/eGSWje+H7pFeuwxvYEPWxuX42CT5kAeHiQoFL8ZlNYmCclpZLwTsdSEtwDXntGekWjqPgviKRSAQ8MNt1YyOgqh+Pw8fMIrfu69Kp9rP/6JxKWau2OheeFP//BjchYqcUe8j/T+Hz9yaTrPcxeAWjuaJZp2mEMhr3zMQJCg6AjoVmQsGLcSSPSkYnt6eGOFk+PwNR5G6RXLLNuy0HUrNsLekMKdBFl4OnpblVYMXy9+JwCwspg4FsL8Gz3KdIrGkWFJrCKiRwyWTIyMvOXzCzxpDZVdAMDfBEba0CvIaT92cGX6/YITcR0sHHdxc8bsxZvlloKDw9YFj993/7I2OBk7mv2Fg4fOy8EiNIfyH2VSf2WlJwGPWlSekMyUshEy2JTTQELrsAKoRj3/ucYN+trqTU/y9fvRbdukxFYMVwIKiV8bdgHZ0hMEd/D38nXTHm9+Nx0ZHLv2nMCD7YcIbVqFAWawCoGWFh5eXqgds0KqF617N1So2o5VCwXIpzRhugEpJM5qITNsFWfbZNqtjFz0Sb4+Jv3U/n5euPTr3ZJNefAgvXzT7bhemSM1OIc2vaYgouXbkIXqJ4MYUFluBOPsBAd+vdsgzkTe2PamFfRqW1jeLi7Q0+vsUkow4LaNciffvePUouaE39cwhuvzyBhFaYS8nzN9PTA4O9r3bw+Rr/VGVPe6443u7dCeRKgfA7slFeio+/56/Q/6Nr/Q6lFw9loPqxi8GHxE5pv+u1fjRV1c/As2hMvjMWV63fg5eUhtdJloIGxf+dstGhSV2qxzPVbMah8/+sIpAFlyZzh423/ZjLaPf2I1FIQ7MN6kYSnv8VjsqCtUikM535ZJLWoMfVh8axeohUf1pYffkPHl8ZDR9qREtZyQsoE4Ic14/BI/RpSq5of9p1E134fIpE0L28yr9NIIypbPgSRpz6X3qHGpVxnIchZG5PJJIGXkpCITxcOQ79XW0utai5fi8LTdI5Xr0cLs1CGh5OBzO6dW6bjuZYPS60azkLTsIqJdDL/rMED8dSeuUjjgax8hpBmduHyLalinZmLNsOFtCulYGFhqcSLBM/kOeulmnNgAXv+1CVs5plRJ9Cl3wfwK1tGqhlh39LjjWoj+vRyi8KKefapBjBc/ApD+j8vJhne6t/eorCa8MFaemDlqoQVm5UpialIvLbeorBiqleOwJXfPsEz9H1slspw3/uGl0G3AXOkFg1nogmsEgQ7iV3oaa/SeanirdC4rPHZ6h/hp5iZTE1LR6dnHyPNJFVqgTjWkd3HkUWmTmHg2Uwl/jRIX3aCKbSLNKRMQ7LKuc6mF5vOB0lrsZWFU/vi9P4FWDStr9SSn+kLN8E/0FeqGbWj5Gg9LhxZYnP4xw9rx6Na1QiVechxdfoo0mR/Oi61aDiLkiOweJCyYsBn5Kxi3oL5d7BgTin569w15JKQUQWckhnU7NE6UsUy2348hkx6r9ERbhx8GTF6rPv0behoUCr9OigTiCnzN0oV+2GtrV2rh5HIU/oS/L1ZNGhHTPhSanEM9jV5BKhNrNQ4PfZ/69wZuANHzyIrKa+/GA796P1GW9SqVk5qsY3DW2ciNSpOqhnxJDPxoy93SDUNZ5F3tf5NWFjRmWRkuyIlww2pma6FLsl0nKwcGvglRGh5KswOU9ixu2rjPjzYcjgCFBHv3K4j06MalYKYMneDMPdkWANq2baJ+D+bNsmp6eL/DIdOLFi2XarZTwYN7LHDuqImDWyeMZPhSYL5c9eL6HNH2XvoL9VMHfdBvQa1hAnmTLbuOmYMPpVgwZidnIZpo3tILbYTEaZD45aPqLRONpN37vldqmk4i5IhsJgAGlgzm8LvgUHwfbRfoYt/ncGYv74e3ZTS8f9F2Azbd+i0cF67hCsK10M7wrNMe/QaPB8B/j7G5TQED6CUyFgyOcaJujXYHDm693eV6ZiRkIRxI7qK/78zqCNAQoaPybDPhk2Wg7+dE3W7oeMkkNm2e8NEpCriuth/4xkciFZdJkgt9sHO+DjSCl0VWk8qCYEX2zWWas7j2KlLwgSX4fCFYDI7y5cNllrs483uTyNd8VAQ15GuQTZH4Gs4jZIjsIgg/wy4RiRB54SCiGQE+Fp3dBcXPJA5ajog0A8BHGgoF6oHBgdAVyEMujIBKmGVnJKOdesmovHD94k2a0yZtx5QrJ/jwedN9ZbNHhB1XkdY96GaKm3Ig8zEGYs2STX7SSOzkP1KHbu1QmJynmno4+2J3w+fxk8H/pBabCeeBjgvI1IpxXTOde+rJFWcR1R0gsr0zqI+q1OzglSzn4b1q/PMilSTcHPD9ZuOBOpqWKJECaw8+EYqZFE6rksALLR4gJgW5YyeCmouaGZRZsGyHSpnO/tiTGe4Rg3uKKb4ZbxJsGzfekiqOc63X76HnNQMEbck4xdRBp16zZRqtpPGv9f0upHw9rNz/aMtpJFwUfY9PyTKKExqexHxYrzOUAld31SF1qVReEqowLr3YKc3O6nNFRYwyuhpHkgsgHq9Ng2Lv9wp2izxy5GzSCRtQZ6a52PkkmB6Z1AnUZfp/crTZBam3/0OVx6sZBIVxpcls2DWACTGcXYPI3wuyUkpeH+m5ehyc3i6k4nmYjLo6TyTFBqcs/D2JPNZ6guG+5wj2R2FryOfqwo6PmucGs5DE1jFAAurcqR1jB7SGcP6ts8r/dpjKP19pWMzVCgbDENUvFgAzfAACqwUjiED5iDBihN7xqJvhHknk5mZjfqNaqOySdAl06tPO1Vclm+AL6Yv/EaqOc7Qvs8jonyocJDLBAT5Y9rM1eL/PM1vCzybCVf1e11IqJ65cF2qOY+wMJ1IkyPDqw0uXLIt3s0cf52/BpiGn9B1r1A+RKpoOANNYBUDHDnNM2o8AzV3Uu+8MrE35tHfrxYPx8VDH+HIvvlIpKe8Umi5hZfBoDGfinp+crFz+xHVU5z0KzFrNXHOOpGORS7jP1iDnGy1A5gFyR0apJyloLBw9DlPEsiwBsfhCc+TlsjC2hbYCe4X5KcyL3m2TczoOZkG9aqpQj04vOHOzWjEsR/NATZsOQQPxXUQ19Dfx2ZhrWEbmsAqJpTahyUee7gWJo3urnJi88wfx1iZY96nZM6ZZBXgNYtsJnI0Oy90lsvUeRuxfuuhfClv3IMDMG72GqnmOA89UA3PvdhcLA6W8fX1wo6dR7Duu0Nwt9E04pizDNISZViI/fHbOdyMVMc5FZYObRohh0xxGe5DFzpfEf3uAFs37Fc9ONj/2OopbWmOsylRAotdCrm5LsJ3WVBRuB/uKe6vUUHMjMnwzGGSIlJdCZuDvmYWOrPQ4kXJpsWcP4Xb1myyL5GeJbauHCtimWQNkdGF6PDxiu/Fej1beLNbK2SwP0iCBYl3SCCe7mp/qMS8T7fi01XmF3s//cSDcPH2UoUdBPj5YPFH34oZRHto88okeIQGqh4cGYnJGNBLy4/lbEqUwEpJ90BuoicSbSgZma73pNDac/AvuHkpBUuuyHZpCq8vjL4cWWiTQ4RSkGm0etMvUovjuLu7YhqZuInxeQ54xh7HM/vz+MKqzEJeT3nhBjr3mS21FMzmHb9i5PDFGDBwLvYfPi21qhnStx2SktRali9pnFUfHSi1FMzED9fhJ9KAlb+R1yN6+Puia4emUouGsyg5AksPLJt8ELnXP0Hu+S+sl8gvMLDzeSSnqnMXlWRM8yyZ4+MVP2DpZ9tEJLoMx1RFhEupjhWMn71WmHNKeLZRT9pBQUW5tpDxJu3LGc535n9DX0KZMJ3w28koNQ9b+GTBUDHzqURXxh+btx1Gzab/ZzUJIQu67oPmojNpPZwyJqB8KJ56ahj+PHtVekceC6b04XVGKi3Lg4NJ6XRdynbGT79YjyXr9MZMTJqyErqwINVv5PWIyxc4L/uHRh4lJ70Mn4Ut9zW/j8Zv//HN8MWWWvD3Ne8b0us9sXTMQQx45TypblKjOYohvQwLHY5ir1+3iip4U0C/h1PL8DrCnPRMEUiqvPk5pcpbb7bDwqk0uBRwlHxAoK9RQyJYWHXr+ATGv91V5UcyxYfMoJXr92HG4k3QkaBi+BYwRMbh9uWvEUGDT03+9DL6WD22rZ2A51s3FHVTjpy4gCbNh0JnYZOGgtLLMA1ajxR9YroImX1DaTEGPNT4fvH9tWuUFw7zazdihIDZ89NxuJLA5/6WYYGUdCsWJ458jIcfqCa1Gvl+7+9o+/zofPmw+JolxSQgonIEXnj2Ubp2VeFLWtStqHjsO/QXdu8+ATe6vv5+alNXT9erBZ3b/s1TpRYNZ1L68mGVQoHF8ADIJ6wIHiIcQMqxS7LwkWFfUOL1KOSmqZPPrdq4H70GzhH+IUYInNvxuH5uBSrauBONi++zqkHKgpHDLOZNekPU87BfYDEtOr2PX0lwmTr5GVsEFhNQ61WkpWWqNE6Gfy/3JefhymVNju8JMkc9yXTkSQql4GHkUI7YMyvyCRiGtdUpk5cjkPrO9LOsKfL3ZPO146Hi5ia0ZZ69FLFsCniyJCjQn75nudSi4WxKoki6J2EtgP0cpoUjznmgmQqr7OxsElZ3sGPHLKkljxkLNwkzToYH7/0NatgsrJiXerRGSmpeTBYP5PlLvpNqhWfXugnI1Bu34HKUxIurRXwaZ/5UPldZqMgTC7ykSUdaKUeac38qBQ5/Rq9PooeaN9KvrjMrrJjJ73bDtGn9YKD+VmW1INhHyJ/jbKLiu0ir5e9RCivxPSTEa1evoAmrIkYTWCUIvvE5/EFPJiLPDO7dMxdtTTKDRpJJcvb3C2LAyqTRe98f3kWq2QYP0ixFzJHsfN+554TUokStSdgCazrjx72WzxfF2HO0K78txbv02wy342BISrFpMTH3I+d4N9yMQY/OTyL27ArpFcv8b9hL2L9nnnCYs4A0FVzmEBowaVWGWzF4d0RXnPl5gfSKRlGhCawigBfxZtIA09tTbkaLAcaawoR3uyM3ajOeampcvKxk6LjPxRKbu59jBzQ93Xt0biG9wzZ4QXFIxVDoSauQj8V77Q0e/Zn0DiPZ2aTZ3CFhIX8fvy82jky1gtfITXqnG5o2rw/95Vt3P8uFj4Vo2+OqZr1Pgi9yE/r2aCOW6eipnzjLp7ysiReKiw0pDCkiBbThdiyebvYgLp9didVLhktHKZgWj9dD2pV1mDOtjxDgom/oWqq/h77fkCz6PTGO+v3F5oi5vgGzxr4mHUWjKNF8WEXgw7p09ba4yU3NPIvQJWDnMqf0LYgTf1yGG28gKpkkufSUDwzwsSlnlikcb8Qa2910LnQenM6l8cO1jHUJ3qjBnWfPJFgL5CR3bJLZAu8czbthK/uDj9HQSqpja5y/dBO79p3CxX9uI4aERlZWDgl6H1QsF0pCvh6eJMHjDHg2krOG8sa00aR1sR+yTJAfqlUKR0sSiI0fUfeTRtGjCawiEFgaGhpFQ0kUSRoaGhpmKbUCK0cs4XEBaelmC+g1XuajoaFx71A6BRYJJFeXXORmuyAry9VsQQ4JNCG4jB/R0NAo/ZTejVR5Vt8k/ZAK/lWcsNO8iysPzYeloVFqKL0+LBZGvCTOUuHVKQUJKw0NjVJF6RVYDGtR1oqGhsY9RekWWBoaGv8pSq8Py1n8y4GjvBlChXLBNie4kznx52WRf0pe6MKBmPdVL6/KUmAr8fok7Nh9An+cuSqCSXn3Gl5wzIGYnAH0mScfkt5ZMHwep+g4ynQ6GZmZeKhuNbtzd506fQUu9BN538VH6tfIt9iY4Qj0c3/fNKaFkbAWlMqbvP5zLeruph0ML7FpUK+qVCuYi//cElHv8vXl1NO8406VSuazUxTErv0ncfj4Bdzk6PnkNHi4uYqt2Ro8UB0vPNPI5gBdhtPo8PpNObA4O8u4n0DZcNvSVMtwcC5vDMtrWitXCEeoSSojW+AxcPGfSNHX3Ed8n4dJC/YdRRNYRSCwWnR8H7/s/BXKnYUtwlOZnKHTzwetnnpIbHr6XMuCUuvyDdkS4BtZHsQGPb7bORcvPPeYsW4DnAl0yryNiDx3DQj0hYuUMYIPyXeFWLfHmQ7oxm3T/nEsmt4XtTkjqhX4Br2v+kt0PMUAMSSQEN9k8+7N2388jvYvjOGdIegepJvQEIfY+F0IDso/aDilTJsWg+j7pLQ4fOKJSfTHfBbVL9buRp/uk+j9imNx/6elY82GSejW6Qmp0TIPtx6Jk7/8yU8bYwMJzfbdW2Hryv8Z6zZw6Ng5jJq8EofoQSE2r/DyhJubcds3HpAsRHNJ8CIxBZXrVcPs8b3wygvNjB+2glv5l5DDm5bIApk+/87E3vhg/OvGegHww0FXuyfSePkUr1c1JOLDJe/g7UEvSO+wnZadx2Pf9sOqfmrTuYVYGO8o/wWRVOyUCfKHR9lg6Gwp5UNF3qgAna/Ixd6241hUaTSggO3eSaJEBCNQcRyEBMPb29q0aR6cr8q3encMHrlErIvTVYkQmQj4Sc6ZCVjbExkKOBtCWBACK4Ri3+HTqPNQH7zcf450FPMITSdI8fv43MqE2KVdsbDypz4RfcOf1wXT+DP/ebHbdXDed3GfkDogvZofX296iISpz09XPgQBVcuie89pQisoiGDqKy/F592p2LqnIS/vadphDJo9NQLHT10Sfct9zFkgeHmW6HsqgaQpi+wQJOSj4wzo1ms6qj02EDGxBulI5gkPD4Kf4txAxT/Adq2bU1ELoUXfKz4fTtq/hSwXBbFv5xHoqF/lc9GRBfDj9l+xasM+6R32owmsEgJrNpy2RFcuBFExegRX6ooz561vb8VP4ruoKpaZtmCjSK7HT3IdmR1KU8oS/F7Oa8X5ojZsOYCIB01zZuVHPh2jAm/jyRGsoXHOKTelOV3Qx20/vEW4/z3I7Onw+gypxTqOfOV5Ml3dI17Ebyf/ho4EFacWkk03a/BGHDp6QEXeSUBYlZfFA8cipidm54myScn34V0c7Nv5n22jB01+U9aHhPPUBY5nt9UEVjHB5hVv764qZGqxv8XUKmetwY8ubL3Gg2BLmhNbGTV5Bd4fu0w81U01Hv4ekfEgPhH6OCqGFLE7svLchJAjTYK1P7/qPcT5OxvhpzKTw744YKG8/4ffSNM9I7U4j7MXb6BOvd5iGzNTfyWbf5wOh3N36Umb4r/sI2NtTAnfFwH0QGvS7K0C0zc7ihvfF07oft6pydeMX9bDww0X/ryEqzeipRb70ARWMcDCitX85k3qoknD+4ylUW00ql9d5Gs3sIAgQaEUDiIDKaniXft9KLUUjs07juDDGavpya5OBcyDhfO8s5O8T/dWWLZgCFYuGY6po7uLbccM0fp8ZhK/NyU6HpeuREkt9w68zf5z3Z2b3jgrMxt1Hx8Mv0ph+UxbzvSaSALquZaPYP7UPli19G0smNYXXdo/LhIzcmJAvkYywtHv6oYDR50vVBlnPCo4tfXtq7dVExsyfO+5+vti9kebpRb7sCCwNDnmTNgn8PCD1fHjugnYt2mKsXwzGQe2TMflXz9Gbsx3+OiDgSJPlFJosR/p27W7pVrh6PzaNASY5Fhn7S4xKg5ff/Ee4s6uxCd0Diy0Xuv6FMYO64KfN09Fdux36NnlSejpBuQZOU6ilxwZh0t/fYl6tStKR7p34EGWkpiMmYs2SS2F56ku4+FO2ptSWPF15rxer1HfcqroLStGi93Ae77UAkP7PI81H48QWVKXLRyGxBjeOCTFqIVdjsSUaX0w8e1u0pFKHjMXb4IbCSW1uZt3X7Mm+9lqddpvWzEvmVyDHbZdNcyTkWHdfBr8+nPYsnESDPRElREX3NtLbHpQGAa99wmpRe7Gp7MECyvW/FJosHS3MjPGn1lBWtfhQx+hXauG6NGpBRIiv0H1KmWld9x7BAQFYMy4L0QfFZaTf/2Dgz8eV5mBLKwMUfHYSA+wFQuHSq3m6dOjFbLogdajc3O0euJBbP9+tt3ZZYub1ev3kVDK84NxmAXn5peFCqcLz0xMw1Yyv+3FvMByryT9R6M46fDMo/Dw8yUTQOG78HLH6QvWne8FsXTlLvgr4rOEzyQhCdeOfap2sFqhySP34bvlo/HVR8NEVtR7Ce4P3mhChjcFcaP+6vRm/nz69jJ25tdik1UlhlgDPpjVHy8930RqsY4baWZfLR6OnV+Po4eGOmV2SUPMAGbn3H04ct9mZ+WIcBulz9NL54fJ8zdINdsxL7C86msa1r9EaLC/ymfBXgXlYLIXsYkomXLKWTc27UYM6SyCE4sLW/ZlZHhDjuK897iv/Xw90fSxOqp+5sDZHZsPiODVwrBj2yExGyjDu/CERATjnYEdpZaix13OKGsLKjPOfqYs2AgfxQONdyzq0r4JJo/qhvT4vA12eQLh2N6T1B/2abHmf4m3FKCmCa1iJzIyVmW60YgiIaZ+QtvDll3H4GIS/Z5DN87M94sxB7mHu5jK5/TOR36/aLFw9P5vJy8aAymLkbiEZOxePxFp0Ql3fYhsjvuGB6Fll/Gi7gi8OzdIu1BG6Kckp2LSu69ItaKHV0NcvxmL0+evme1zuRylwufLYasuDrre78TqcfH4BdXDiTc64WDoOjUrICC8jNjkQ8YlOAATZq+TarZhWfR6OrbMQMNxOOyA16KwSXKX5DSxPMZRzpI5yUs9ZHipBe9HyLE9xQEPfN4iq0O3KWjYYgiatBxusTRsPgQvvT4DuhDHBbQjyKEjo0mIGxQ7CXGMWvydBCz6fIfUYh/HTl4CTPZU5A1EOrRuJFWKHvadffbVj3ig8SCzfS6XxlRqP9KPtMws4WNyhEkfroer4tpxv4ZVCceD91cR9QGvPYMU+v0y7Hxf/OVOqWYbls8ssB89iqX/axQapVlgypXrd9Cl34f4cP5G6Mi2lxFxOKRe16jquIP72s2YvE0mCN6woV7t4vdRshDi4McCSyG0ycIyY8yr8KYBrox9CyAtYOjoT6SafYgt9RV9L7Q30j4qm8zWFjW8vtRsX5spjgor5rOvdhlXEkgk08N2cO+2Ug0YOeAF5JKGKWuxPCPL28AdOHpW1G3B8tnpRhlNQs0sLDS8h+BBuii8tKJSw/53S1i93nAJ74RqD7yB774/ikATn1JSnAFzJ/aWao6RkpZhnG2U4BkbexbT/tf45vNRSI7R3x1UbJ670PV7ub/98XC8iFyJOKJ78Wi2xc3WH48hkwSULPBE/6Wlk5DqIOoML8Ku81BN1Q7oHoG+mEoPaluxLLDcgkiffFwTWE6ATTze3+9OrAFxZHLIhR2SATp/sc6KnbxKwcJR59Xvq4QRigvuCD7sD5IGH8PnEhefZ/YUB3zzcmQ/xxEVVDi6/t+EQzceaVJX5YAP8PPGhq9/woVLt6QW2/AyMbvF1c0o/qySHJ5hrq/NFUd36ubdyL1I+Mik0+9s2KRevofju4M7IY3ubRmepf5h51Gbv9e6/he23GgWakKr0LCg4OUwyiKi2ZX+KoIHNy/N4P3vLv26RGp1nErlQ5GtmHXk4MVTZwo382UP/HvSSdNo1bw+OrRphOdbN7RYOrR5FC2bPohUxRb6/wZ7N05CuiKIlx8kPmFl0OrliaJuq0+a06nwFL+MeCCRuXnxcqTUUvSwsKpZrRw6PdfYbJ8ry0vtHhc/zV6hxX6pw/tPqnYjT09KxayxPaVaHm90e1r0gbJv4eGGRcu2i3pBWBdYnvfR46WdJrCcAF8gS4XjrsQyjMQUse15txebI/ovelg4gXp1KompdBlW2TOi9aRl5U0xFzXphhSs+2QkmVvvYvMX71ksbI5xnFdGMZ6bOVgrGDqqGwyGvIwZPPN14/It7Nh9HLoA2+LQHmtQC7ybtgo/L2zklCvFRAoJ/55dn8T6T9822+fKsmbpCBFWoooDtIFZSzbT7/JWWQiupDl9+/1RDBi1FP3e+fhuGTH+S1SrWVEVuuNL/T3FRrPQusBiypHk42NrQsthWCixQOJ1eeqSAEOMXph/HBM1ol8H3Lm6Dms+Hil9svC0b90IuUl5KjjjFhyAUVNXSbXiwXq6nDwS+H02ajBFyYKpfeBBg1c5De8fokPv4YuFRqHKJmGB+2qUp9/iKq6/DKdqmTLP/oDJwsCmnq3YK6yYWYu/FcvIlLAZvXTlD/h8zW58uXbP3bLoix0iXY7Suc/WRuyV2zh78abUYpmCe52pfJTUOPqrCS2HYHu+acPayI3fivira++WuCtrkXxzI3JufYMrR5di7qTehc7IaErLZg8APuqnJvvLvvh8Oy7RTWIPcQmJqPPEf2d3oa+XDBcOeBkeZGyu/vzrGdJE8i/sNcdz7ZsIX6UMm+SpZC69P3O11GI7DVqPFFlJSxK/nriA9LhE6pv8/SHnVTMt5mYi3ekhOmXeeqlmGdsEltejQNlPNKHlIPyEdRXpjIGgQL+7hZO+cSxKUTPojbaqjAusuvuRYKz5+GCREtkWOI1yxIN9cP7cVTzxgu2ZNUszXdo3RT0y65RLSniwGYWVbWrgjLGvIdMk6V5gkD+mTV+NZV//JLUUzBMdx+LUyb9Rsf6bpPXZrwUVFZPmrIdnUH4TWXZ3WCtK2Pm+ZqP5LLFKbBNYjK4/EDFHE1oOkqtablO8LJlB1y4zW6VlscOfn4Bla/TAYlLTrbFg2XYEV3pZ+HF0JOgOHj6DDr2mS6/e2wgHfJQ6i4Y9Nivnin+idUOxHEqGHxicGbXfwLno2HummEG1xKHfziOk7uv095zoe29/H/jX6C69+u/CffL990fh5ZUXY8htnBJHuDusFr1qcblY3UH354r1e6UW89gusJigkUD5VRB50DWhVar4dvVYJF6/I9WMsNDigTPkvU/hWfllEkIzMH3hN1hI5uLU+RvQ9tWp8KjYFcPHfIYAeh/7Ghgdqe/bth5C134fiPq9TFioDn0GdxLpXRxl76bJyCJTUhmQykKLs8tu/+k4fCp0QeO272L09K+wkB4OHy7dgt7DF4nMrs3avC00PDk8gGfiWHZ6Vy2+5T2WYH8UB8bKM90srHhh96mfF+LWuVW4dnq52XL99Aok3dwglpwphZZ3gA9mf/StVDOPfQKLCegJVL9OPe6hCa5SRMdnH8OYCb2hvxGj0hbEwCEBxANh177fMXbGagz73zKMm7UWew78CW8fT/G6cj2ciMCnQdSvZxup5d5m2ZzB9C/H0jlmirHf6u9jnyD5VoxqxpZhn05gSCD+OHsNsxdvxrD3l2HUxOVY/c3PpJWlIzC8zN0HhYCuXQaZ5y/bsCFFUTPn4y3wVaxTZV9to0froH7dqiJIlENqzJWK5UOEdj9maGekKFwVvFzszIkLiIyKl1ryY7/AYtwrktAiNTZ4tDFOSxNcpYLpY17FnDmDYLgZo4o2Ztg34+PjJVLH8No/3hSB/Qqms2FsviTFJODAvgV45skGUuu9D4dbJClyldkLL6+6RFpHamq6SIKohB8aXl4eQoviFNS8PIsHNGvAiueEEJj6G9EYNqQzVhaQR6uo4a3Vrp2/ptoTIN2QjAlv2675Dez1rAj7kB+g3A+udP9NsxLi4JjAkgmZAdSiL2PBxfAYYAHG368sGnw1pP84D0eOOHLgCzhzchn8fLyhj4oTQZ1Kjcsc/DpHfutvxYp1cPobG9HsMesLsuVz45vQsTNV4Pyus5tXO7dA9dqVhdbjKNWrRIgZ4XZPN4T+WpQ4ljqVkHnYlOQ8+0kpqdj63TTMn9JHesUGiqjvpi/YCHd6sMkI/ygJ2PZtGkotttGt5zOqsAuewf7oc8tBpIUTWDIsuGpQx1c+AgT9H5145TzNiwsLspJahHbouH/CHPEJici8HQe9VDKoxMVZ357JPqivSdhwSmX5O+gLpKyOBXN/rYqIPv0lNq8Zj1rVywmNSx+jh16fbMwxnpxKWkCqqHM7v167Znn8sHU6LhxcLLagsoTwSSTknZf+dix1SGw+U8gSQvNLVH6efps+ThUPpUTM4MXnvZf7BDFULJCSRoMjOu/9nCI6x4oJouTPvfNI63ElgX3n7ue5ZFFJIDPNVrat+h/+PruSBncjJMYajMdJSBKBwzyby4U3ARGbgdyMFtrv7MlvIPfWJvEZa9yJTkCy4txAJUlhdhVEnOnnqa94EbMpqxavQRbfH9L7Ei9H4v/6Pi+9ajucJyvrxq2849xJoO+Mxsp15p3v5jdSdRa5ZDZmx9Bf/sEl4DFpFhogbmVJdNu/s60lblOnc+yN7Izkp6iXlzvKR1jeL89eOIaKTQYZfgqXLxtscwZRU9hfxfmoIu/E0w2aTsfxQERYEB5+oBqeLXBj1zzYbPnn+h2V34WFVbXK4TYFW7JgunKNPq8wNVgI1qxazuwtxBriddL8lN/HfWEpwwXP1t2mQanMr85hAjVI+7EVjoXi32TUHo3aBQeEhjsYQ8c7bvMs4LVbMSJwlu8b3vuwdo3yaN2iPiJCpU1ibeDq9Wh6nCl2fqbfFkyaUJAiC4g1OHMId7RsEHDfhIcEqnYUZ42IM1Eol+Jwn7MGKX+vPfD9ovSRcn9yxH0Fup9NKVqBpaGhoeFEnGMSamhoaBQDmsDS0NAoNWgCS0NDo9SgCSwNDY1SAvD/xmeTq4aFiYkAAAAASUVORK5CYII=\" height=\"20\" width=\"200\">");
*/		sb.append("</body> </html>");

		MessageBody body = new MessageBody(sb.toString());
		
		/* // creates message part
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(htmlBody, "text/html");
 
        // creates multi-part
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);
 
        // adds inline image attachments
        if (mapInlineImages != null && mapInlineImages.size() > 0) {
            Set<String> setImageID = mapInlineImages.keySet();
             
            for (String contentId : setImageID) {
                MimeBodyPart imagePart = new MimeBodyPart();
                imagePart.setHeader("Content-ID", "<" + contentId + ">");
                imagePart.setDisposition(MimeBodyPart.INLINE);
                 
                String imageFilePath = mapInlineImages.get(contentId);
                try {
                    imagePart.attachFile(imageFilePath);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
 
                multipart.addBodyPart(imagePart);
            }
        }
 
        msg.setContent(multipart);
 
        Transport.send(msg);*/
		
		
		body.setBodyType(BodyType.HTML);
		log.info("Mail Body: "+body);
		return body;
	}
	
	public void sendMail(String msg,String mailId,String mailSubject) {
		log.debug("Entering Sent Mail....");
		try {
			/*if(mail.getCategory().equalsIgnoreCase("OTHERS")) {	
				moveUnclassifiedMailToCustomFolder(mail);
			}		
			else {*/
				/*EmailMessage email = EmailMessage.bind(service,id);
				email.setIsRead(true);
				email.update(ConflictResolutionMode.AlwaysOverwrite);*/
			log.info("Mail Details of user: Mail From : " +supportId+ " Mail To :"+mailId+" mailSubject: "+mailSubject);
			service = intantiateService();
				EmailMessage message = new EmailMessage(service);
				EmailAddress from = new EmailAddress(supportId);
				message.setSubject(mailSubject);
				MessageBody hmtlBody = composeHtmlBody(msg);				
				message.setBody(hmtlBody);
				message.getToRecipients().add(mailId);
				message.setFrom(from);
				message.sendAndSaveCopy(WellKnownFolderName.SentItems);	

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<EmailInfo> readEmails() throws Exception{
		log.debug("Entering readEmails()...");
		
		service = intantiateService();

		PropertySet itempropertyset = new PropertySet(BasePropertySet.FirstClassProperties);
		itempropertyset.setRequestedBodyType( BodyType.Text);
		ItemView itemview = new ItemView(Integer.parseInt(PropertyReader.readProperties("MAIL_COUNT")));
		itemview.setPropertySet(itempropertyset);

		List<EmailInfo> unReadMailData= new ArrayList<EmailInfo>();
		Folder folder = Folder.bind(service, WellKnownFolderName.Inbox);
		SearchFilter searchFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, false));
		FindItemsResults<Item> results = service.findItems(folder.getId(), searchFilter,itemview);

		for (Item item : results) {

			Item itm = Item.bind(service, item.getId(), PropertySet.FirstClassProperties);
			itm.load(itempropertyset);
			EmailMessage emailMessage = EmailMessage.bind(service, itm.getId());

			EmailInfo emailContent = new EmailInfo();
			emailContent.setFrom(emailMessage.getFrom().getAddress().toString());
			emailContent.setSubject(emailMessage.getSubject().toString());
			emailContent.setItemId(itm.getId());
			emailContent.setReceivedDateTime(emailMessage.getDateTimeReceived());
			emailContent.setMessage(itm.getBody().toString());
			unReadMailData.add(emailContent);			
		}

		return unReadMailData;
	}

}
