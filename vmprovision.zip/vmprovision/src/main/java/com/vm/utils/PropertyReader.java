package com.vm.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class PropertyReader {

	private static String PROPERTIES_FILE_NAME = "vm_provision.properties";

    //private static final String PROPERTIES_FILE_LOCATION = "C:/WORKSPACE/vmprovision/src/main/java/com/vm/cfg/";
	
	static ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	static InputStream input = classLoader.getResourceAsStream("com/vm/cfg/vm_provision.properties");

    public static Properties properties = null;
    public static final String CLASS_NAME = PropertyReader.class.getName();
    static Logger sharedLog = Logger.getLogger(CLASS_NAME);

    //Basically used to set the property file as Letter Property
    public static void setPropertyFilName(String pName) {
        PROPERTIES_FILE_NAME = pName;
    }

    //Basically used to reset the property file as Penta.properties
    public static void resetPropertyFilName() {
        PROPERTIES_FILE_NAME = "vm_provision.properties";
    }
    public static String readProperties(String pKey) throws Exception {

        InputStream in = null;

        if (properties == null) {
            properties = new Properties();
            try {
                //properties.load(new FileInputStream(PROPERTIES_FILE_LOCATION + PROPERTIES_FILE_NAME));
            	properties.load(input);
            } catch (IOException e) {
                sharedLog.error("Failure to read the properties FILE:" + PROPERTIES_FILE_NAME + " from LOCATION: " + input);
                throw e;
            } finally {
                try {
                    if (in != null) {
                        in.close();
                    }
                } catch (Exception e) {
                }
            }
        }

        String value = properties.getProperty(pKey);

        if ((value == null) || (value.trim().equals(""))) {

            sharedLog.debug("No Key available in the properties file for key:" + pKey);

            throw new Exception();
        } else {
            value = value.trim();
        }

        return value;
    }
   
}
